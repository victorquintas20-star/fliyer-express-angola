package com.fliyerexpress.angola;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EditText event = findViewById(R.id.eventName);
        EditText date = findViewById(R.id.date);
        EditText time = findViewById(R.id.time);
        EditText location = findViewById(R.id.location);
        EditText description = findViewById(R.id.description);
        TextView preview = findViewById(R.id.preview);
        Button generate = findViewById(R.id.generate);

        generate.setOnClickListener(v -> preview.setText(
            event.getText().toString() + "\n\n" +
            date.getText().toString() + "  •  " + time.getText().toString() + "\n" +
            location.getText().toString() + "\n\n" +
            description.getText().toString()
        ));
    }
}
